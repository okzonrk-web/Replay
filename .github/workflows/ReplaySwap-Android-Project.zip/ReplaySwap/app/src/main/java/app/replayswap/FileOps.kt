package app.replayswap

import android.content.Context
import android.os.Environment
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object FileOps {

    data class SwapResult(val success: Boolean, val message: String)

    // Path folder Replay standar Mobile Legends
    private const val MLBB_REPLAY_PATH = "Android/data/com.mobile.legends/files/dragon2017/assets/BattleRecord"
    private const val APP_BACKUP_DIR = "ReplaySwap/Backups"
    private const val PREFS_NAME = "replayswap_prefs"
    private const val KEY_ACTIVE_SLOT = "active_slot_index"

    fun getGameReplayDir(): File {
        val root = Environment.getExternalStorageDirectory()
        return File(root, MLBB_REPLAY_PATH)
    }

    fun getBackupStorageDir(): File {
        val root = Environment.getExternalStorageDirectory()
        val dir = File(root, APP_BACKUP_DIR)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun getCurrentSlotName(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val currentSlot = prefs.getInt(KEY_ACTIVE_SLOT, 1)
        val slotDir = File(getBackupStorageDir(), "slot_$currentSlot")
        val noteFile = File(slotDir, "label.txt")
        val label = if (noteFile.exists()) noteFile.readText() else "Slot $currentSlot"
        return "Slot $currentSlot ($label)"
    }

    fun swapToSlot(context: Context, slotNumber: Int): SwapResult {
        return try {
            val gameDir = getGameReplayDir()
            val slotDir = File(getBackupStorageDir(), "slot_$slotNumber")

            if (!slotDir.exists() || slotDir.listFiles().isNullOrEmpty()) {
                return SwapResult(false, "Slot $slotNumber masih kosong! Silakan backup replay terlebih dahulu.")
            }

            // Copy file replay dari slot ke folder game
            if (!gameDir.exists()) {
                gameDir.mkdirs()
            }

            // Bersihkan file replay lama di game atau swap
            val slotFiles = slotDir.listFiles() ?: arrayOf()
            for (file in slotFiles) {
                if (file.isFile && file.name.endsWith(".battle", ignoreCase = true)) {
                    val destFile = File(gameDir, file.name)
                    copyFile(file, destFile)
                }
            }

            // Simpan slot aktif ke SharedPreferences
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putInt(KEY_ACTIVE_SLOT, slotNumber).apply()

            SwapResult(true, "Swap ke Slot $slotNumber selesai! Muat ulang menu Replay di dalam game.")
        } catch (e: Exception) {
            SwapResult(false, "Error: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    fun backupCurrentGameReplay(context: Context): Boolean {
        return try {
            val gameDir = getGameReplayDir()
            if (!gameDir.exists()) return false

            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val currentSlot = prefs.getInt(KEY_ACTIVE_SLOT, 1)
            val slotDir = File(getBackupStorageDir(), "slot_$currentSlot")
            if (!slotDir.exists()) {
                slotDir.mkdirs()
            }

            val files = gameDir.listFiles() ?: return false
            var copiedCount = 0
            for (file in files) {
                if (file.isFile && file.name.endsWith(".battle", ignoreCase = true)) {
                    val dest = File(slotDir, file.name)
                    copyFile(file, dest)
                    copiedCount++
                }
            }

            val timeStamp = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date())
            File(slotDir, "label.txt").writeText("Saved at $timeStamp")
            copiedCount > 0
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun copyFile(source: File, dest: File) {
        FileInputStream(source).use { input ->
            FileOutputStream(dest).use { output ->
                val buffer = ByteArray(4096)
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    output.write(buffer, 0, read)
                }
            }
        }
    }
}
