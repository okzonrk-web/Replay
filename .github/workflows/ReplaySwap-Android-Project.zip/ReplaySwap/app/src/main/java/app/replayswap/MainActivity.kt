package app.replayswap

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var btnToggleBubble: Button
    private lateinit var btnRequestOverlay: Button
    private lateinit var btnRequestStorage: Button
    private lateinit var tvStatusOverlay: TextView
    private lateinit var tvStatusStorage: TextView
    private lateinit var tvActiveSlot: TextView

    companion object {
        private const val REQUEST_OVERLAY_CODE = 101
        private const val REQUEST_STORAGE_CODE = 102
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        checkPermissionsAndUpdateUI()
        setupListeners()
    }

    private fun initViews() {
        btnToggleBubble = findViewById(R.id.btnToggleBubble)
        btnRequestOverlay = findViewById(R.id.btnRequestOverlay)
        btnRequestStorage = findViewById(R.id.btnRequestStorage)
        tvStatusOverlay = findViewById(R.id.tvStatusOverlay)
        tvStatusStorage = findViewById(R.id.tvStatusStorage)
        tvActiveSlot = findViewById(R.id.tvActiveSlot)

        tvActiveSlot.text = "Slot Aktif: " + FileOps.getCurrentSlotName(this)
    }

    private fun setupListeners() {
        btnRequestOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivityForResult(intent, REQUEST_OVERLAY_CODE)
            } else {
                Toast.makeText(this, "Izin Overlay sudah aktif!", Toast.LENGTH_SHORT).show()
            }
        }

        btnRequestStorage.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (!Environment.isExternalStorageManager()) {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.data = Uri.parse("package:$packageName")
                    startActivityForResult(intent, REQUEST_STORAGE_CODE)
                } else {
                    Toast.makeText(this, "Akses File Penuh sudah aktif!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Akses penyimpanan standar sudah didukung", Toast.LENGTH_SHORT).show()
            }
        }

        btnToggleBubble.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Harap aktifkan Izin Overlay terlebih dahulu!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            if (BubbleService.isRunning) {
                val stopIntent = Intent(this, BubbleService::class.java)
                stopService(stopIntent)
                btnToggleBubble.text = "Mulai Floating Bubble"
                Toast.makeText(this, "Floating Bubble dihentikan", Toast.LENGTH_SHORT).show()
            } else {
                val startIntent = Intent(this, BubbleService::class.java)
                ContextCompat.startForegroundService(this, startIntent)
                btnToggleBubble.text = "Hentikan Floating Bubble"
                Toast.makeText(this, "Bubble ReplaySwap siap di atas layar!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkPermissionsAndUpdateUI()
    }

    private fun checkPermissionsAndUpdateUI() {
        val hasOverlay = Settings.canDrawOverlays(this)
        val hasStorage = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            true
        }

        tvStatusOverlay.text = if (hasOverlay) "Overlay: DIIZINKAN" else "Overlay: BELUM DIIZINKAN"
        tvStatusStorage.text = if (hasStorage) "File Access: AKTIF" else "File Access: BELUM AKTIF"

        btnToggleBubble.text = if (BubbleService.isRunning) "Hentikan Floating Bubble" else "Mulai Floating Bubble"
    }
}
