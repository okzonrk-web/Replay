package app.replayswap

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private var expandedMenu: View? = null
    private var params: WindowManager.LayoutParams? = null

    companion object {
        var isRunning = false
        private const val CHANNEL_ID = "replayswap_bubble_channel"
        private const val NOTIFICATION_ID = 2024
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        startForeground(NOTIFICATION_ID, createNotification())

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        setupFloatingBubble()
    }

    private fun createNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "ReplaySwap Floating Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifikasi background agar bubble ReplaySwap tetap melayang"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ReplaySwap Aktif")
            .setContentText("Ketuk bubble di layar untuk swap file replay saat bermain")
            .setSmallIcon(android.R.drawable.ic_menu_rotate)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun setupFloatingBubble() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 200
        }

        val inflater = LayoutInflater.from(this)
        floatingView = inflater.inflate(R.layout.layout_floating_bubble, null)
        expandedMenu = inflater.inflate(R.layout.layout_bubble_menu, null)

        val bubbleIcon = floatingView?.findViewById<ImageView>(R.id.ivBubbleIcon)
        expandedMenu?.visibility = View.GONE

        // Gesture Drag & Drop
        bubbleIcon?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isMoved = false

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params?.x ?: 0
                        initialY = params?.y ?: 0
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isMoved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isMoved = true
                        }
                        params?.x = initialX + dx
                        params?.y = initialY + dy
                        windowManager.updateViewLayout(floatingView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!isMoved) {
                            toggleMenu()
                        }
                        return true
                    }
                }
                return false
            }
        })

        // Setup Klik Menu Replay
        setupMenuActions()

        windowManager.addView(floatingView, params)
    }

    private fun toggleMenu() {
        val menuContainer = floatingView?.findViewById<View>(R.id.menuContainer)
        if (menuContainer?.visibility == View.VISIBLE) {
            menuContainer.visibility = View.GONE
        } else {
            menuContainer?.visibility = View.VISIBLE
            updateMenuSlotLabels()
        }
    }

    private fun updateMenuSlotLabels() {
        val tvSlotInfo = floatingView?.findViewById<TextView>(R.id.tvCurrentSlot)
        tvSlotInfo?.text = "Slot: " + FileOps.getCurrentSlotName(this)
    }

    private fun setupMenuActions() {
        val btnSlot1 = floatingView?.findViewById<View>(R.id.btnSlot1)
        val btnSlot2 = floatingView?.findViewById<View>(R.id.btnSlot2)
        val btnSlot3 = floatingView?.findViewById<View>(R.id.btnSlot3)
        val btnBackup = floatingView?.findViewById<View>(R.id.btnBackupNow)
        val btnClose = floatingView?.findViewById<View>(R.id.btnCloseBubble)

        btnSlot1?.setOnClickListener { performSwap(1) }
        btnSlot2?.setOnClickListener { performSwap(2) }
        btnSlot3?.setOnClickListener { performSwap(3) }

        btnBackup?.setOnClickListener {
            CoroutineScope(Dispatchers.IO).launch {
                val success = FileOps.backupCurrentGameReplay(applicationContext)
                withContext(Dispatchers.Main) {
                    val msg = if (success) "Replay berhasil di-backup!" else "Gagal backup replay!"
                    Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
                }
            }
        }

        btnCloseBubble?.setOnClickListener {
            stopSelf()
        }
    }

    private fun performSwap(slotIndex: Int) {
        CoroutineScope(Dispatchers.IO).launch {
            val result = FileOps.swapToSlot(applicationContext, slotIndex)
            withContext(Dispatchers.Main) {
                if (result.success) {
                    Toast.makeText(
                        applicationContext,
                        "Berhasil swap ke Slot $slotIndex: ${result.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                    updateMenuSlotLabels()
                } else {
                    Toast.makeText(
                        applicationContext,
                        "Gagal swap: ${result.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
                toggleMenu()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        if (floatingView != null) {
            windowManager.removeView(floatingView)
        }
    }
}
